#!/bin/bash
# This file exists for backwards compatibility with older versions of Dingdang.
# It might be removed in future versions.
"${0%/*}/../dingdang.py"
